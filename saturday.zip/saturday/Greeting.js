import React from 'react'

// function Greeting()
// {
//     return <h1>Hello Rachana Gattu</h1>
// }
const Greeting = () => <h1>Hello Rachana Gattu how are you? </h1>
export default Greeting