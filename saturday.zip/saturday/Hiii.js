import React from 'react'
 const Hiii = props => {
     const {name, heroname}=props
     //const {name,heroname}=this.props
     return <h1>Hello  iam {name} my fav hero is {heroname} </h1>
 }
// const Hiii= () => <h1>Hello Rachana Gattu how are you? </h1>
export default Hiii;