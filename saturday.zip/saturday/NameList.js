// {
//     const names = ['Shiva','Ganesh','Vishnu']
//     const nameList = names.map(name => <h2>{name}</h2>)
//     return(
//         <div>
//             {/* <h2>{names[0]}</h2>
//             <h2>{names[1]}</h2>
//             <h2>{names[2]}</h2> */}
//             {
//                 // names.map(name =><h2>{name}</h2>)
//                 nameList
//             }
//         </div>
//     )
// }
import React from 'react'
function NameList()
{
 const persons = 
   [
        {
            id: 1,
            name: 'Shiva',
            age: 30,
            skill: 'React'
        },
        {
            id: 2,
            name: 'Ganesh',
            age: 25,
            skill: 'Angular'
        },
        {
            id: 3,
            name: 'Vishnu',
            age: 28,
            skill: 'React'
        }
   ]
 const personList = persons.map(person => <h2>Iam {person.name}. I am {person.age} years old. I Know {person.skill}</h2>)
 return <div>{personList}</div>
}
export default NameList