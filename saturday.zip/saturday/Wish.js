import React, { Component } from 'react';
class Wish extends Component{
    render()
    {
        return <h1>Happy Birthday Rachana</h1>
    }
}
export default  Wish 